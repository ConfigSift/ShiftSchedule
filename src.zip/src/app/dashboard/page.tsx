﻿import { Dashboard } from '../../components';

export default function DashboardPage() {
  return <Dashboard />;
}
